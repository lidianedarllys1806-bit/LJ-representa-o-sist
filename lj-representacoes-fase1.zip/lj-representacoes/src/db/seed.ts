import { db } from "./index";
import { empresas, usuarios } from "./schema";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";

async function main() {
  const empresaExistente = await db.select().from(empresas).limit(1);
  if (empresaExistente.length === 0) {
    await db.insert(empresas).values({
      razaoSocial: "LJ Representações Comerciais LTDA",
      nomeFantasia: "LJ Representações",
      cnpj: "00.000.000/0001-00",
      email: "contato@ljrepresentacoes.com.br",
      cidade: "Maceió",
      estado: "AL",
    });
    console.log("✓ Empresa criada");
  }

  const adminExistente = await db
    .select()
    .from(usuarios)
    .where(eq(usuarios.email, "admin@lj.com"))
    .limit(1);

  if (adminExistente.length === 0) {
    const senhaHash = await bcrypt.hash("lj@2026", 10);
    await db.insert(usuarios).values({
      nome: "Administradora LJ",
      email: "admin@lj.com",
      senhaHash,
      perfil: "ADMIN",
    });
    console.log("✓ Usuário admin criado (admin@lj.com / lj@2026)");
  } else {
    console.log("Usuário admin já existe.");
  }
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
