import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { relations, sql } from "drizzle-orm";

/**
 * FASE 1 — FUNDAÇÃO
 * Entidades: Empresa, Usuario, Auditoria.
 * As demais entidades do modelo completo (Representada, Cliente, Produto,
 * Orcamento, Pedido, Comissao, Agenda, etc.) serão adicionadas nas Fases 2+,
 * conforme o plano de desenvolvimento em docs/arquitetura-lj-representacoes.md.
 */

export const perfilEnum = ["ADMIN", "REPRESENTANTE", "FINANCEIRO", "AUXILIAR"] as const;
export type Perfil = (typeof perfilEnum)[number];

export const empresas = sqliteTable("empresas", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  razaoSocial: text("razao_social").notNull().default("LJ Representações"),
  nomeFantasia: text("nome_fantasia").notNull().default("LJ Representações"),
  cnpj: text("cnpj"),
  telefone: text("telefone"),
  email: text("email"),
  endereco: text("endereco"),
  cidade: text("cidade"),
  estado: text("estado"),
  logoUrl: text("logo_url"),
  corPrincipal: text("cor_principal").default("#0B5D4C"),
  createdAt: text("created_at").default(sql`(current_timestamp)`),
  updatedAt: text("updated_at").default(sql`(current_timestamp)`),
});

export const usuarios = sqliteTable("usuarios", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  nome: text("nome").notNull(),
  email: text("email").notNull().unique(),
  senhaHash: text("senha_hash").notNull(),
  perfil: text("perfil", { enum: perfilEnum }).notNull().default("REPRESENTANTE"),
  ativo: integer("ativo", { mode: "boolean" }).notNull().default(true),
  avatarUrl: text("avatar_url"),
  telefone: text("telefone"),
  // Estrutura preparada para 2FA / Passkeys (Fase 9 / item 55)
  totpSecret: text("totp_secret"),
  totpAtivo: integer("totp_ativo", { mode: "boolean" }).notNull().default(false),
  createdAt: text("created_at").default(sql`(current_timestamp)`),
  updatedAt: text("updated_at").default(sql`(current_timestamp)`),
});

export const auditoria = sqliteTable("auditoria", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  usuarioId: text("usuario_id").references(() => usuarios.id),
  acao: text("acao").notNull(), // criar | editar | excluir | arquivar | login...
  entidade: text("entidade").notNull(), // ex: "usuario", "cliente"
  entidadeId: text("entidade_id"),
  valorAnterior: text("valor_anterior"), // JSON serializado
  valorNovo: text("valor_novo"), // JSON serializado
  createdAt: text("created_at").default(sql`(current_timestamp)`),
});

export const usuariosRelations = relations(usuarios, ({ many }) => ({
  auditorias: many(auditoria),
}));

export const auditoriaRelations = relations(auditoria, ({ one }) => ({
  usuario: one(usuarios, {
    fields: [auditoria.usuarioId],
    references: [usuarios.id],
  }),
}));
