"use client";

import { useState } from "react";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Pendencia } from "@/lib/demo-data";

export function ListaPendencias({ itens }: { itens: Pendencia[] }) {
  const [concluidas, setConcluidas] = useState<Set<string>>(new Set());

  function toggle(id: string) {
    setConcluidas((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  return (
    <ul className="flex flex-col gap-2">
      {itens.map((item) => {
        const feita = concluidas.has(item.id);
        return (
          <li
            key={item.id}
            className="flex items-center gap-3 rounded-[var(--radius-sm)] border border-border px-3 py-2.5"
          >
            <button
              onClick={() => toggle(item.id)}
              aria-label="Marcar como concluída"
              className={cn(
                "flex h-5 w-5 shrink-0 items-center justify-center rounded-full border transition",
                feita ? "border-primary bg-primary" : "border-border bg-surface"
              )}
            >
              {feita && <Check className="h-3 w-3 text-white" />}
            </button>
            <div className="min-w-0 flex-1">
              <p
                className={cn(
                  "truncate text-[13.5px] font-medium",
                  feita ? "text-muted line-through" : "text-ink"
                )}
              >
                {item.titulo}
              </p>
              <p className="truncate text-[12px] text-muted">
                {item.tipo}
                {item.cliente ? ` · ${item.cliente}` : ""}
              </p>
            </div>
            <span className="shrink-0 text-[11px] font-medium text-muted">{item.prazo}</span>
          </li>
        );
      })}
    </ul>
  );
}
