import { Card } from "@/components/ui/Card";
import { Construction } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export function ModuloEmConstrucao({
  titulo,
  fase,
  descricao,
  icon: Icon,
}: {
  titulo: string;
  fase: string;
  descricao: string;
  icon: LucideIcon;
}) {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink">{titulo}</h1>
        <p className="mt-0.5 text-[13.5px] text-muted">{descricao}</p>
      </div>

      <Card className="flex flex-col items-center justify-center gap-3 py-16 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary-light">
          <Icon className="h-6 w-6 text-primary-dark" />
        </div>
        <div className="flex items-center gap-1.5 text-warning">
          <Construction className="h-4 w-4" />
          <span className="text-[13px] font-semibold uppercase tracking-wide">FUTURO</span>
        </div>
        <p className="max-w-sm text-[13.5px] text-muted">
          Este módulo será construído na <strong className="text-ink">{fase}</strong>,
          seguindo o plano de fases do projeto. Nenhum botão ou tela falsa foi
          criado aqui — quando chegarmos nesta fase, o módulo será implementado
          por completo (cadastro, cálculo, PDF, permissões e testes).
        </p>
      </Card>
    </div>
  );
}
