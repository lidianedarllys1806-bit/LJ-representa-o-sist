import { Search, LogOut } from "lucide-react";
import { auth, signOut } from "@/lib/auth";

export default async function Topbar() {
  const session = await auth();
  const nome = session?.user?.name ?? "Usuário";
  const iniciais = nome
    .split(" ")
    .slice(0, 2)
    .map((p) => p[0])
    .join("")
    .toUpperCase();

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border bg-surface/90 px-4 backdrop-blur lg:px-6">
      <div className="relative hidden flex-1 max-w-md sm:block">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
        <input
          placeholder="Buscar cliente, orçamento, representada..."
          className="h-10 w-full rounded-[var(--radius-sm)] border border-border bg-bg pl-9 pr-3 text-sm outline-none focus:border-primary"
        />
      </div>

      <div className="ml-auto flex items-center gap-3">
        <div className="hidden text-right leading-tight sm:block">
          <p className="text-[13px] font-medium text-ink">{nome}</p>
          <p className="text-[11px] text-muted">{session?.user?.email}</p>
        </div>
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary-light text-[12px] font-semibold text-primary-dark">
          {iniciais}
        </div>
        <form
          action={async () => {
            "use server";
            await signOut({ redirectTo: "/login" });
          }}
        >
          <button
            type="submit"
            title="Sair"
            className="flex h-9 w-9 items-center justify-center rounded-[var(--radius-sm)] text-muted transition hover:bg-bg hover:text-ink"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </form>
      </div>
    </header>
  );
}
