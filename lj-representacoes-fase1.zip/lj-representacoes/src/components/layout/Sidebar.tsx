"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { navItems } from "@/lib/nav-items";
import { cn } from "@/lib/utils";

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden lg:flex lg:w-[248px] lg:shrink-0 lg:flex-col lg:border-r lg:border-border lg:bg-surface">
      <div className="flex h-16 items-center gap-2.5 border-b border-border px-5">
        <div className="flex h-9 w-9 items-center justify-center rounded-[var(--radius-sm)] bg-primary font-display text-sm font-bold text-white">
          LJ
        </div>
        <div className="leading-tight">
          <p className="font-display text-[15px] font-semibold text-ink">LJ Representações</p>
          <p className="text-[11px] text-muted">Central de gestão</p>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4">
        <ul className="flex flex-col gap-0.5">
          {navItems.map((item) => {
            const active = pathname === item.href || pathname.startsWith(item.href + "/");
            const Icon = item.icon;
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={cn(
                    "group flex items-center justify-between gap-2.5 rounded-[var(--radius-sm)] px-3 py-2.5 text-[14px] font-medium transition",
                    active
                      ? "bg-primary-light text-primary-dark"
                      : "text-muted hover:bg-bg hover:text-ink"
                  )}
                >
                  <span className="flex items-center gap-2.5">
                    <Icon
                      className={cn(
                        "h-[18px] w-[18px] shrink-0",
                        active ? "text-primary-dark" : "text-muted group-hover:text-ink"
                      )}
                    />
                    {item.label}
                  </span>
                  {item.emBreve && (
                    <span className="rounded-full bg-bg px-1.5 py-0.5 text-[10px] font-normal text-muted">
                      em breve
                    </span>
                  )}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </aside>
  );
}
