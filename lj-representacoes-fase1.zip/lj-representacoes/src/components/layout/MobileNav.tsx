"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import { mobilePrimaryItems, navItems } from "@/lib/nav-items";
import { cn } from "@/lib/utils";

export default function MobileNav() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <>
      {/* Barra inferior fixa */}
      <nav className="fixed inset-x-0 bottom-0 z-40 flex h-16 items-center justify-around border-t border-border bg-surface/95 backdrop-blur lg:hidden">
        {mobilePrimaryItems.map((item) => {
          const active = pathname === item.href || pathname.startsWith(item.href + "/");
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-1 flex-col items-center gap-1 py-2 text-[11px] font-medium",
                active ? "text-primary" : "text-muted"
              )}
            >
              <Icon className="h-5 w-5" />
              {item.label.split(" ")[0]}
            </Link>
          );
        })}
        <button
          onClick={() => setOpen(true)}
          className="flex flex-1 flex-col items-center gap-1 py-2 text-[11px] font-medium text-muted"
        >
          <Menu className="h-5 w-5" />
          Menu
        </button>
      </nav>

      {/* Drawer com o menu completo */}
      {open && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div
            className="absolute inset-0 bg-black/40"
            onClick={() => setOpen(false)}
          />
          <div className="relative ml-auto flex h-full w-[82%] max-w-[320px] flex-col bg-surface">
            <div className="flex h-16 items-center justify-between border-b border-border px-5">
              <p className="font-display text-[15px] font-semibold text-ink">Menu</p>
              <button onClick={() => setOpen(false)} aria-label="Fechar menu">
                <X className="h-5 w-5 text-muted" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto px-3 py-4">
              <ul className="flex flex-col gap-0.5">
                {navItems.map((item) => {
                  const active = pathname === item.href || pathname.startsWith(item.href + "/");
                  const Icon = item.icon;
                  return (
                    <li key={item.href}>
                      <Link
                        href={item.href}
                        onClick={() => setOpen(false)}
                        className={cn(
                          "flex items-center justify-between gap-2.5 rounded-[var(--radius-sm)] px-3 py-3 text-[15px] font-medium",
                          active ? "bg-primary-light text-primary-dark" : "text-ink"
                        )}
                      >
                        <span className="flex items-center gap-3">
                          <Icon className="h-[18px] w-[18px]" />
                          {item.label}
                        </span>
                        {item.emBreve && (
                          <span className="rounded-full bg-bg px-1.5 py-0.5 text-[10px] font-normal text-muted">
                            em breve
                          </span>
                        )}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </nav>
          </div>
        </div>
      )}
    </>
  );
}
