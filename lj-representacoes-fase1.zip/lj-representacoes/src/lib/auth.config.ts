import type { NextAuthConfig } from "next-auth";

/**
 * Configuração "leve", sem dependências de Node.js (banco de dados, bcrypt).
 * É a única parte do Auth.js usada pelo middleware (Edge Runtime).
 * A configuração completa, com o provider de credenciais e acesso ao banco,
 * fica em src/lib/auth.ts e roda apenas em rotas Node.js normais.
 */
export const authConfig = {
  pages: {
    signIn: "/login",
  },
  session: { strategy: "jwt" },
  providers: [],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.perfil = (user as { perfil?: string }).perfil;
        token.id = user.id;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as { perfil?: string; id?: string }).perfil = token.perfil as string;
        (session.user as { perfil?: string; id?: string }).id = token.id as string;
      }
      return session;
    },
  },
} satisfies NextAuthConfig;
