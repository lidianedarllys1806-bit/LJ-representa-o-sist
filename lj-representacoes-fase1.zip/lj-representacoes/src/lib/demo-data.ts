// Dados demonstrativos — usados apenas para visualizar o layout do Dashboard
// nesta Fase 1. A partir da Fase 2 (Cadastros) e Fase 3 (Orçamentos), estes
// dados passam a vir do banco (Representada, Cliente, Orçamento, Pedido...).

export const resumoDemo = [
  { label: "Vendas do mês", valor: "R$ 84.320", variacao: "+12% vs mês anterior" },
  { label: "Comissão prevista", valor: "R$ 6.745", variacao: "8% médio" },
  { label: "Orçamentos abertos", valor: "9", variacao: "3 aguardando aprovação" },
  { label: "Pedidos abertos", valor: "5", variacao: "2 em faturamento" },
];

export type Pendencia = {
  id: string;
  titulo: string;
  tipo: string;
  prazo: string;
  cliente?: string;
};

export const pendenciasDemo = {
  urgentes: [
    { id: "p1", titulo: "Orçamento #125 vence hoje", tipo: "Orçamento", prazo: "Hoje", cliente: "Distribuidora Alfa" },
    { id: "p2", titulo: "Pedido #087 aguardando retorno", tipo: "Pedido", prazo: "Atrasado 2 dias", cliente: "Comercial Beta" },
  ] as Pendencia[],
  hoje: [
    { id: "p3", titulo: "Follow-up orçamento #131", tipo: "Follow-up", prazo: "Hoje", cliente: "Empresa Gamma" },
    { id: "p4", titulo: "Enviar catálogo Kisafix", tipo: "Tarefa", prazo: "Hoje", cliente: "Distribuidora Alfa" },
  ] as Pendencia[],
  proximas: [
    { id: "p5", titulo: "Renovação de contrato — Kisafix", tipo: "Documento", prazo: "Em 5 dias" },
    { id: "p6", titulo: "Visita — Comercial Beta", tipo: "Visita", prazo: "Em 3 dias" },
  ] as Pendencia[],
};

export const agendaHojeDemo = [
  { hora: "09:00", tipo: "Visita", titulo: "Distribuidora Alfa" },
  { hora: "11:30", tipo: "Follow-up", titulo: "Orçamento #125" },
  { hora: "14:00", tipo: "Pedido", titulo: "Conferir pedido #087" },
  { hora: "16:00", tipo: "Viagem", titulo: "Preparar viagem para Arapiraca" },
];

export const oportunidadesDemo = [
  { cliente: "Empresa Gamma", estagio: "Negociação", potencial: "Alto", valor: "R$ 18.000" },
  { cliente: "Comercial Beta", estagio: "Orçamento enviado", potencial: "Médio", valor: "R$ 9.400" },
  { cliente: "Distribuidora Alfa", estagio: "Prospecção", potencial: "Alto", valor: "R$ 22.000" },
];

export const desempenhoDemo = {
  meta: 100000,
  realizado: 84320,
};

export const movimentacoesDemo = [
  { id: "125", tipo: "Orçamento", cliente: "Distribuidora Alfa", status: "Aguardando aprovação", valor: "R$ 7.200" },
  { id: "087", tipo: "Pedido", cliente: "Comercial Beta", status: "Em faturamento", valor: "R$ 5.850" },
  { id: "131", tipo: "Orçamento", cliente: "Empresa Gamma", status: "Enviado", valor: "R$ 18.000" },
  { id: "084", tipo: "Pedido", cliente: "Distribuidora Alfa", status: "Faturado", valor: "R$ 3.100" },
];
