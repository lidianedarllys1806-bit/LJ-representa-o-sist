import {
  LayoutDashboard,
  Bell,
  Target,
  Factory,
  Users,
  Package,
  FileText,
  ShoppingCart,
  Wallet,
  Calendar,
  Plane,
  Ticket,
  Flag,
  BarChart3,
  Paperclip,
  Settings,
  type LucideIcon,
} from "lucide-react";

export type NavItem = {
  label: string;
  href: string;
  icon: LucideIcon;
  /** Módulos ainda não implementados nesta fase (mostram selo "Em breve") */
  emBreve?: boolean;
};

export const navItems: NavItem[] = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { label: "Pendências", href: "/pendencias", icon: Bell, emBreve: true },
  { label: "Oportunidades", href: "/oportunidades", icon: Target, emBreve: true },
  { label: "Representadas", href: "/representadas", icon: Factory, emBreve: true },
  { label: "Clientes / CRM", href: "/clientes", icon: Users, emBreve: true },
  { label: "Produtos", href: "/produtos", icon: Package, emBreve: true },
  { label: "Orçamentos", href: "/orcamentos", icon: FileText, emBreve: true },
  { label: "Pedidos", href: "/pedidos", icon: ShoppingCart, emBreve: true },
  { label: "Comissões", href: "/comissoes", icon: Wallet, emBreve: true },
  { label: "Agenda", href: "/agenda", icon: Calendar, emBreve: true },
  { label: "Viagens", href: "/viagens", icon: Plane, emBreve: true },
  { label: "Eventos", href: "/eventos", icon: Ticket, emBreve: true },
  { label: "Metas", href: "/metas", icon: Flag, emBreve: true },
  { label: "Relatórios", href: "/relatorios", icon: BarChart3, emBreve: true },
  { label: "Documentos", href: "/documentos", icon: Paperclip, emBreve: true },
  { label: "Configurações", href: "/configuracoes", icon: Settings },
];

/** Itens de destaque na navegação inferior mobile (máx. 5) */
export const mobilePrimaryItems: NavItem[] = [
  navItems[0], // Dashboard
  navItems[1], // Pendências
  navItems[9], // Agenda
  navItems[4], // Clientes
];
