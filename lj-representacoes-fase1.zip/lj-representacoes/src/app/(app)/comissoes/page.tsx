import { ModuloEmConstrucao } from "@/components/ModuloEmConstrucao";
import { Wallet } from "lucide-react";

export default function ComissoesPage() {
  return (
    <ModuloEmConstrucao
      titulo="Comissões"
      fase="Fase 5 — Comissões"
      descricao="Regras de comissão, previsão e recebimentos."
      icon={Wallet}
    />
  );
}
