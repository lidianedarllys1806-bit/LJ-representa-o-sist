import { ModuloEmConstrucao } from "@/components/ModuloEmConstrucao";
import { ShoppingCart } from "lucide-react";

export default function PedidosPage() {
  return (
    <ModuloEmConstrucao
      titulo="Pedidos"
      fase="Fase 4 — Pedidos"
      descricao="Conversão de orçamentos aprovados, faturamento e devoluções."
      icon={ShoppingCart}
    />
  );
}
