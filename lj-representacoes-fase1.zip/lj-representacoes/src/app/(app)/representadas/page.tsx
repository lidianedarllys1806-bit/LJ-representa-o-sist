import { ModuloEmConstrucao } from "@/components/ModuloEmConstrucao";
import { Factory } from "lucide-react";

export default function RepresentadasPage() {
  return (
    <ModuloEmConstrucao
      titulo="Representadas"
      fase="Fase 2 — Cadastros"
      descricao="Cadastro de representadas, comissões e condições."
      icon={Factory}
    />
  );
}
