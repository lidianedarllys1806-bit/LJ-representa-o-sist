import { ModuloEmConstrucao } from "@/components/ModuloEmConstrucao";
import { Flag } from "lucide-react";

export default function MetasPage() {
  return (
    <ModuloEmConstrucao
      titulo="Metas"
      fase="Fase 8 — Gestão"
      descricao="Metas mensais por representada, cliente e período."
      icon={Flag}
    />
  );
}
