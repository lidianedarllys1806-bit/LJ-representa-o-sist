"use server";

import { db } from "@/db";
import { empresas, usuarios } from "@/db/schema";
import { eq } from "drizzle-orm";
import { auth } from "@/lib/auth";
import { revalidatePath } from "next/cache";

export async function atualizarEmpresaAction(formData: FormData): Promise<void> {
  const [empresa] = await db.select().from(empresas).limit(1);
  if (!empresa) return;

  await db
    .update(empresas)
    .set({
      razaoSocial: String(formData.get("razaoSocial") || ""),
      nomeFantasia: String(formData.get("nomeFantasia") || ""),
      cnpj: String(formData.get("cnpj") || ""),
      telefone: String(formData.get("telefone") || ""),
      email: String(formData.get("email") || ""),
      cidade: String(formData.get("cidade") || ""),
      estado: String(formData.get("estado") || ""),
      updatedAt: new Date().toISOString(),
    })
    .where(eq(empresas.id, empresa.id));

  revalidatePath("/configuracoes");
}

export async function listarUsuariosAction() {
  return db.select().from(usuarios);
}

export async function sessaoAtualAction() {
  return auth();
}
