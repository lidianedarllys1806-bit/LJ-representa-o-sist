import { db } from "@/db";
import { empresas, usuarios } from "@/db/schema";
import { Card, CardHeader } from "@/components/ui/Card";
import { StatusPill } from "@/components/ui/Badges";
import { atualizarEmpresaAction } from "./actions";
import { Save } from "lucide-react";

const perfilLabel: Record<string, string> = {
  ADMIN: "Administrador",
  REPRESENTANTE: "Representante",
  FINANCEIRO: "Financeiro",
  AUXILIAR: "Auxiliar",
};

export default async function ConfiguracoesPage() {
  const [empresa] = await db.select().from(empresas).limit(1);
  const listaUsuarios = await db.select().from(usuarios);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink">Configurações</h1>
        <p className="mt-0.5 text-[13.5px] text-muted">
          Dados da empresa e usuários com acesso ao sistema.
        </p>
      </div>

      <Card>
        <CardHeader title="Dados da empresa" />
        <form action={atualizarEmpresaAction} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Campo label="Razão social" name="razaoSocial" defaultValue={empresa?.razaoSocial ?? ""} />
          <Campo label="Nome fantasia" name="nomeFantasia" defaultValue={empresa?.nomeFantasia ?? ""} />
          <Campo label="CNPJ" name="cnpj" defaultValue={empresa?.cnpj ?? ""} />
          <Campo label="Telefone" name="telefone" defaultValue={empresa?.telefone ?? ""} />
          <Campo label="E-mail" name="email" defaultValue={empresa?.email ?? ""} type="email" />
          <Campo label="Cidade" name="cidade" defaultValue={empresa?.cidade ?? ""} />
          <Campo label="Estado" name="estado" defaultValue={empresa?.estado ?? ""} />

          <div className="sm:col-span-2">
            <button
              type="submit"
              className="flex h-10 items-center gap-2 rounded-[var(--radius-sm)] bg-primary px-4 text-[14px] font-medium text-white transition hover:bg-primary-dark"
            >
              <Save className="h-4 w-4" />
              Salvar alterações
            </button>
          </div>
        </form>
      </Card>

      <Card>
        <CardHeader title="Usuários" />
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[13px]">
            <thead>
              <tr className="text-[11.5px] uppercase tracking-wide text-muted">
                <th className="pb-2 font-medium">Nome</th>
                <th className="pb-2 font-medium">E-mail</th>
                <th className="pb-2 font-medium">Perfil</th>
                <th className="pb-2 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {listaUsuarios.map((u) => (
                <tr key={u.id} className="border-t border-border">
                  <td className="py-2.5 font-medium text-ink">{u.nome}</td>
                  <td className="py-2.5 text-muted">{u.email}</td>
                  <td className="py-2.5 text-ink">{perfilLabel[u.perfil]}</td>
                  <td className="py-2.5">
                    <StatusPill tone={u.ativo ? "success" : "neutral"}>
                      {u.ativo ? "Ativo" : "Inativo"}
                    </StatusPill>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-[12px] text-muted">
          Convite e criação de novos usuários com controle de permissões por
          módulo entram na Fase 6 (Gestão de acesso avançada).
        </p>
      </Card>
    </div>
  );
}

function Campo({
  label,
  name,
  defaultValue,
  type = "text",
}: {
  label: string;
  name: string;
  defaultValue: string;
  type?: string;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={name} className="text-sm font-medium text-ink">
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        defaultValue={defaultValue}
        className="h-10 rounded-[var(--radius-sm)] border border-border bg-surface px-3 text-[14px] outline-none focus:border-primary"
      />
    </div>
  );
}
