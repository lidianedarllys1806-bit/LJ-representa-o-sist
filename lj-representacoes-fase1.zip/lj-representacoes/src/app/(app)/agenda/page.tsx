import { ModuloEmConstrucao } from "@/components/ModuloEmConstrucao";
import { Calendar } from "lucide-react";

export default function AgendaPage() {
  return (
    <ModuloEmConstrucao
      titulo="Agenda"
      fase="Fase 6 — CRM e Agenda"
      descricao="Visualização por dia, semana, mês e lista de compromissos."
      icon={Calendar}
    />
  );
}
