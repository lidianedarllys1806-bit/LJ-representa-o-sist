import { ModuloEmConstrucao } from "@/components/ModuloEmConstrucao";
import { FileText } from "lucide-react";

export default function OrcamentosPage() {
  return (
    <ModuloEmConstrucao
      titulo="Orçamentos"
      fase="Fase 3 — Orçamentos"
      descricao="Criação de orçamentos, cálculo automático e geração de PDF."
      icon={FileText}
    />
  );
}
