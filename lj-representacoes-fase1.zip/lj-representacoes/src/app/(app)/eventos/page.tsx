import { ModuloEmConstrucao } from "@/components/ModuloEmConstrucao";
import { Ticket } from "lucide-react";

export default function EventosPage() {
  return (
    <ModuloEmConstrucao
      titulo="Eventos"
      fase="Fase 7 — Viagens e Eventos"
      descricao="Feiras, convenções e eventos com representadas."
      icon={Ticket}
    />
  );
}
