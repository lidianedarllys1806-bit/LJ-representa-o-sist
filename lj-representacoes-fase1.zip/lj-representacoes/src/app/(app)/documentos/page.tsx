import { ModuloEmConstrucao } from "@/components/ModuloEmConstrucao";
import { Paperclip } from "lucide-react";

export default function DocumentosPage() {
  return (
    <ModuloEmConstrucao
      titulo="Documentos"
      fase="Fase 6 — CRM e Agenda"
      descricao="Central de documentos e anexos vinculados a clientes e pedidos."
      icon={Paperclip}
    />
  );
}
