import { ModuloEmConstrucao } from "@/components/ModuloEmConstrucao";
import { Package } from "lucide-react";

export default function ProdutosPage() {
  return (
    <ModuloEmConstrucao
      titulo="Produtos"
      fase="Fase 2 — Cadastros"
      descricao="Catálogo de produtos e tabelas de preço."
      icon={Package}
    />
  );
}
