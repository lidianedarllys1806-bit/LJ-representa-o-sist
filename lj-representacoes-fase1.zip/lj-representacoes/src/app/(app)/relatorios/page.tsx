import { ModuloEmConstrucao } from "@/components/ModuloEmConstrucao";
import { BarChart3 } from "lucide-react";

export default function RelatoriosPage() {
  return (
    <ModuloEmConstrucao
      titulo="Relatórios"
      fase="Fase 8 — Gestão"
      descricao="Relatórios de vendas, comissões, conversão e desempenho."
      icon={BarChart3}
    />
  );
}
