import { ModuloEmConstrucao } from "@/components/ModuloEmConstrucao";
import { Plane } from "lucide-react";

export default function ViagensPage() {
  return (
    <ModuloEmConstrucao
      titulo="Viagens"
      fase="Fase 7 — Viagens e Eventos"
      descricao="Planejamento de viagens, compromissos e despesas."
      icon={Plane}
    />
  );
}
