import { ModuloEmConstrucao } from "@/components/ModuloEmConstrucao";
import { Target } from "lucide-react";

export default function OportunidadesPage() {
  return (
    <ModuloEmConstrucao
      titulo="Oportunidades"
      fase="Fase 6 — CRM e Agenda"
      descricao="Funil de prospecção e negociações em andamento."
      icon={Target}
    />
  );
}
