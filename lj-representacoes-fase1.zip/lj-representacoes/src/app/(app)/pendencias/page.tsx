import { ModuloEmConstrucao } from "@/components/ModuloEmConstrucao";
import { Bell } from "lucide-react";

export default function PendenciasPage() {
  return (
    <ModuloEmConstrucao
      titulo="Pendências"
      fase="Fase 6 — CRM e Agenda"
      descricao="Central de pendências urgentes, para hoje e próximas."
      icon={Bell}
    />
  );
}
