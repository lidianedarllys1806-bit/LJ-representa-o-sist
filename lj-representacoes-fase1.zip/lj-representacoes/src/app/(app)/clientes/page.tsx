import { ModuloEmConstrucao } from "@/components/ModuloEmConstrucao";
import { Users } from "lucide-react";

export default function ClientesPage() {
  return (
    <ModuloEmConstrucao
      titulo="Clientes / CRM"
      fase="Fase 2 — Cadastros"
      descricao="Cadastro de clientes, contatos e histórico comercial."
      icon={Users}
    />
  );
}
