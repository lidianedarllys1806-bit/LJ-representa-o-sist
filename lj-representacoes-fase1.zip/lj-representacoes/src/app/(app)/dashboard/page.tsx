import { auth } from "@/lib/auth";
import { Card, CardHeader } from "@/components/ui/Card";
import { StatusPill } from "@/components/ui/Badges";
import { ListaPendencias } from "@/components/dashboard/ListaPendencias";
import {
  resumoDemo,
  pendenciasDemo,
  agendaHojeDemo,
  oportunidadesDemo,
  desempenhoDemo,
  movimentacoesDemo,
} from "@/lib/demo-data";
import { TrendingUp, MapPin, Phone, Package as PackageIcon, ClipboardList } from "lucide-react";

const iconePorTipo: Record<string, React.ElementType> = {
  Visita: MapPin,
  "Follow-up": Phone,
  Pedido: PackageIcon,
  Viagem: ClipboardList,
};

function saudacao() {
  const hora = new Date().getHours();
  if (hora < 12) return "Bom dia";
  if (hora < 18) return "Boa tarde";
  return "Boa noite";
}

export default async function DashboardPage() {
  const session = await auth();
  const primeiroNome = session?.user?.name?.split(" ")[0] ?? "";
  const hoje = new Date().toLocaleDateString("pt-BR", {
    weekday: "long",
    day: "2-digit",
    month: "long",
  });
  const percentualMeta = Math.round(
    (desempenhoDemo.realizado / desempenhoDemo.meta) * 100
  );

  return (
    <div className="flex flex-col gap-6">
      {/* Cabeçalho */}
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink">
          {saudacao()}, {primeiroNome}!
        </h1>
        <p className="mt-0.5 text-[13.5px] capitalize text-muted">{hoje}</p>
        <p className="mt-2 rounded-[var(--radius-sm)] bg-info-light px-3 py-2 text-[12.5px] text-info">
          Dados desta tela são demonstrativos — os módulos de Orçamentos, Pedidos e
          CRM ainda serão implementados nas próximas fases.
        </p>
      </div>

      {/* Resumo */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {resumoDemo.map((item) => (
          <Card key={item.label} className="p-4">
            <p className="text-[12.5px] text-muted">{item.label}</p>
            <p className="mt-1 font-display text-xl font-semibold text-ink">{item.valor}</p>
            <p className="mt-1 text-[11.5px] text-primary">{item.variacao}</p>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Pendências */}
        <Card className="lg:col-span-2">
          <CardHeader title="🔔 Pendências" />
          <div className="flex flex-col gap-5">
            <div>
              <p className="mb-2 text-[12px] font-semibold uppercase tracking-wide text-danger">
                Urgentes
              </p>
              <ListaPendencias itens={pendenciasDemo.urgentes} />
            </div>
            <div>
              <p className="mb-2 text-[12px] font-semibold uppercase tracking-wide text-warning">
                Para hoje
              </p>
              <ListaPendencias itens={pendenciasDemo.hoje} />
            </div>
            <div>
              <p className="mb-2 text-[12px] font-semibold uppercase tracking-wide text-info">
                Próximas
              </p>
              <ListaPendencias itens={pendenciasDemo.proximas} />
            </div>
          </div>
        </Card>

        {/* Agenda de hoje */}
        <Card>
          <CardHeader title="📅 Agenda de hoje" />
          <ul className="flex flex-col gap-3">
            {agendaHojeDemo.map((ev, i) => {
              const Icon = iconePorTipo[ev.tipo] ?? ClipboardList;
              return (
                <li key={i} className="flex items-start gap-3">
                  <span className="mt-0.5 w-11 shrink-0 text-[12.5px] font-semibold text-primary">
                    {ev.hora}
                  </span>
                  <Icon className="mt-0.5 h-4 w-4 shrink-0 text-muted" />
                  <div className="min-w-0">
                    <p className="truncate text-[13.5px] font-medium text-ink">{ev.titulo}</p>
                    <p className="text-[11.5px] text-muted">{ev.tipo}</p>
                  </div>
                </li>
              );
            })}
          </ul>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Oportunidades */}
        <Card className="lg:col-span-2">
          <CardHeader title="🎯 Oportunidades" />
          <div className="overflow-x-auto">
            <table className="w-full text-left text-[13px]">
              <thead>
                <tr className="text-[11.5px] uppercase tracking-wide text-muted">
                  <th className="pb-2 font-medium">Cliente</th>
                  <th className="pb-2 font-medium">Estágio</th>
                  <th className="pb-2 font-medium">Potencial</th>
                  <th className="pb-2 text-right font-medium">Valor</th>
                </tr>
              </thead>
              <tbody>
                {oportunidadesDemo.map((op) => (
                  <tr key={op.cliente} className="border-t border-border">
                    <td className="py-2.5 font-medium text-ink">{op.cliente}</td>
                    <td className="py-2.5 text-muted">{op.estagio}</td>
                    <td className="py-2.5">
                      <StatusPill tone={op.potencial === "Alto" ? "success" : "warning"}>
                        {op.potencial}
                      </StatusPill>
                    </td>
                    <td className="py-2.5 text-right font-medium text-ink">{op.valor}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Desempenho */}
        <Card>
          <CardHeader title="📈 Desempenho" />
          <div className="flex flex-col gap-3">
            <div className="flex items-end justify-between">
              <div>
                <p className="text-[12px] text-muted">Realizado</p>
                <p className="font-display text-lg font-semibold text-ink">
                  R$ {desempenhoDemo.realizado.toLocaleString("pt-BR")}
                </p>
              </div>
              <div className="flex items-center gap-1 text-primary">
                <TrendingUp className="h-4 w-4" />
                <span className="text-[13px] font-semibold">{percentualMeta}%</span>
              </div>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-full bg-bg">
              <div
                className="h-full rounded-full bg-primary"
                style={{ width: `${Math.min(percentualMeta, 100)}%` }}
              />
            </div>
            <p className="text-[12px] text-muted">
              Meta do mês: R$ {desempenhoDemo.meta.toLocaleString("pt-BR")}
            </p>
          </div>
        </Card>
      </div>

      {/* Movimentações recentes */}
      <Card>
        <CardHeader title="📦 Últimas movimentações" />
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[13px]">
            <thead>
              <tr className="text-[11.5px] uppercase tracking-wide text-muted">
                <th className="pb-2 font-medium">Nº</th>
                <th className="pb-2 font-medium">Tipo</th>
                <th className="pb-2 font-medium">Cliente</th>
                <th className="pb-2 font-medium">Status</th>
                <th className="pb-2 text-right font-medium">Valor</th>
              </tr>
            </thead>
            <tbody>
              {movimentacoesDemo.map((m) => (
                <tr key={m.id} className="border-t border-border">
                  <td className="py-2.5 font-medium text-ink">#{m.id}</td>
                  <td className="py-2.5 text-muted">{m.tipo}</td>
                  <td className="py-2.5 text-ink">{m.cliente}</td>
                  <td className="py-2.5">
                    <StatusPill
                      tone={
                        m.status === "Faturado"
                          ? "success"
                          : m.status === "Em faturamento"
                          ? "info"
                          : "warning"
                      }
                    >
                      {m.status}
                    </StatusPill>
                  </td>
                  <td className="py-2.5 text-right font-medium text-ink">{m.valor}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
