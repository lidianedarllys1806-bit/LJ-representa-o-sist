"use client";

import { useActionState } from "react";
import { loginAction } from "./actions";
import { Loader2 } from "lucide-react";

export default function LoginForm({ callbackUrl }: { callbackUrl: string }) {
  const [state, formAction, isPending] = useActionState(loginAction, {});

  return (
    <form action={formAction} className="flex flex-col gap-4">
      <input type="hidden" name="callbackUrl" value={callbackUrl} />

      <div className="flex flex-col gap-1.5">
        <label htmlFor="email" className="text-sm font-medium text-ink">
          E-mail
        </label>
        <input
          id="email"
          name="email"
          type="email"
          required
          autoFocus
          placeholder="voce@ljrepresentacoes.com.br"
          className="h-11 rounded-[var(--radius-sm)] border border-border bg-surface px-3.5 text-[15px] outline-none transition focus:border-primary"
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="senha" className="text-sm font-medium text-ink">
          Senha
        </label>
        <input
          id="senha"
          name="senha"
          type="password"
          required
          placeholder="••••••••"
          className="h-11 rounded-[var(--radius-sm)] border border-border bg-surface px-3.5 text-[15px] outline-none transition focus:border-primary"
        />
      </div>

      {state?.erro && (
        <p className="rounded-[var(--radius-sm)] bg-danger-light px-3 py-2 text-sm text-danger">
          {state.erro}
        </p>
      )}

      <button
        type="submit"
        disabled={isPending}
        className="mt-2 flex h-11 items-center justify-center gap-2 rounded-[var(--radius-sm)] bg-primary text-[15px] font-medium text-white transition hover:bg-primary-dark disabled:opacity-70"
      >
        {isPending && <Loader2 className="h-4 w-4 animate-spin" />}
        Entrar
      </button>

      <p className="text-center text-xs text-muted">
        Acesso demonstrativo: admin@lj.com / lj@2026
      </p>
    </form>
  );
}
