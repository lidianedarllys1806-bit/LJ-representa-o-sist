"use server";

import { signIn } from "@/lib/auth";
import { AuthError } from "next-auth";

export async function loginAction(
  _prevState: { erro?: string } | undefined,
  formData: FormData
): Promise<{ erro?: string }> {
  const email = formData.get("email") as string;
  const senha = formData.get("senha") as string;
  const callbackUrl = (formData.get("callbackUrl") as string) || "/dashboard";

  try {
    await signIn("credentials", {
      email,
      senha,
      redirectTo: callbackUrl,
    });
    return {};
  } catch (err) {
    if (err instanceof AuthError) {
      return { erro: "E-mail ou senha incorretos." };
    }
    // NEXT_REDIRECT precisa ser relançado para o redirecionamento funcionar
    throw err;
  }
}
